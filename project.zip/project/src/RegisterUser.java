import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterUser
 */
public class RegisterUser extends HttpServlet {
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			try{  
				PrintWriter out=response.getWriter();  
				String fname=request.getParameter("firstname");
				String lname=request.getParameter("lastname");
				String email=request.getParameter("email");
				String uname=request.getParameter("username");
				String pass=request.getParameter("userpass");
				Class.forName("oracle.jdbc.OracleDriver");
				 System.out.println("syccessfully loaded driver");
				Connection con = DriverManager.getConnection
						("jdbc:oracle:thin:@//localhost:1521/XE","DB1","aditya");
				System.out.println("succesfully connected");
			      
			PreparedStatement ps=con.prepareStatement("insert into userreg(first_name, last_name, email, uername, pass, regdate) values(?,?,?,?,?,CURRENT_DATE)");
			ps.setString(1,fname);  
			ps.setString(2,lname);  
			ps.setString(3,email);  
			ps.setString(4,uname);  
			ps.setString(5,pass);  
			ps.executeUpdate();
			
			out.println("<script type=\"text/javascript\">");
		  	   out.println("alert('Record inserted!!!');");
		  	   out.println("location='index.html';");
		  	   out.println("</script>");
			
			con.close();
			
	}
			catch(Exception e)
			{
				System.out.println(e);
			}


		}
	}
