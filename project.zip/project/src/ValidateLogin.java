import java.sql.*;  
  
public class ValidateLogin {  
public static boolean validate(String name,String pass){  
boolean status=false;  
try{  

	Class.forName("oracle.jdbc.OracleDriver");
	 System.out.println("syccessfully loaded driver");
	Connection con = DriverManager.getConnection
			("jdbc:oracle:thin:@//localhost:1521/XE","DB1","aditya");
	System.out.println("succesfully connected");
      
PreparedStatement ps=con.prepareStatement(  
"select * from userreg where uername=? and pass=?");  
ps.setString(1,name);  
ps.setString(2,pass);  
      
ResultSet rs=ps.executeQuery();  
status=rs.next();
}catch(Exception e){System.out.println(e);}  
return status;  
}  
}  