
import java.io.IOException;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class airpollution extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	String username= request.getParameter("username"); 
		HttpSession session2=request.getSession();
		session2.setAttribute("username", username);
		try{ 
			PrintWriter out=response.getWriter();  
			String name=request.getParameter("name");
			String feedback=request.getParameter("feedair");
			
			Class.forName("oracle.jdbc.OracleDriver");
			 System.out.println("syccessfully loaded driver");
			Connection con = DriverManager.getConnection
					("jdbc:oracle:thin:@//localhost:1521/XE","DB1","aditya");
			System.out.println("succesfully connected");
		      
		PreparedStatement ps=con.prepareStatement("insert into airpollution(name,feedback) values (?,?)");
		ps.setString(1,name);
		ps.setString(2,feedback);
		ps.executeUpdate();
		
		out.println("<script type=\"text/javascript\">");
	  	   out.println("alert('Record inserted!!!');");
	  	   out.println("location='treecutting.html';");
	  	   out.println("</script>");
		
	
		con.close();
		
}
		
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
	}

	

}
