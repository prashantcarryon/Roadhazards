

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class complaintsServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	try {
		PrintWriter out=response.getWriter(); 
		String username=request.getParameter("username");
		String location=request.getParameter("Location");
		String email=request.getParameter("Email");
		String phoneNum=request.getParameter("Number");
		String address=request.getParameter("Address");
		Class.forName("oracle.jdbc.OracleDriver");
		 System.out.println("syccessfully loaded driver");
		Connection con = DriverManager.getConnection
				("jdbc:oracle:thin:@//localhost:1521/XE","DB1","aditya");
		System.out.println("succesfully connected");
			String strQuery ="insert into $userdetails (location ,email, phoneNum ,address) values($loc,$emal,$pno,$addrs))";
		String query1 =strQuery.replace("$userdetails",username);
		String query2 =query1.replace("$loc",location);
		String query3 =query2.replace("$emal",email);
		String query4 =query3.replace("$pno",phoneNum);
		String query5 =query4.replace("$addrs",address);
		PreparedStatement ps2=con.prepareStatement(query5);
		ps2.executeUpdate(); 
		System.out.println("done");
		
	}catch (Exception e) {
		System.out.println(e);
	}
	}

	

}
